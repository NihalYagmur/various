import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.Scanner;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
public class Test {
	public static ArrayList<String> lines = new ArrayList<String>();
	public static ArrayList<String> lines2 = new ArrayList<String>();
	public static ArrayList<String> lines3 = new ArrayList<String>();
	public static ArrayList<String> lines4 = new ArrayList<String>();
	public static ArrayList<String> lines5 = new ArrayList<String>();
	
	public static ArrayList<String> linesw = new ArrayList<String>();
	
	public static ArrayList<String> nums = new ArrayList<String>();
	public static ArrayList<String> nums2 = new ArrayList<String>();

	public static ArrayList<String> letter2 = new ArrayList<String>();
	public static ArrayList<String> letter3 = new ArrayList<String>();

	public static ArrayList<String> ger3 = new ArrayList<String>();
	public static ArrayList<String> en3 = new ArrayList<String>();
	public static ArrayList<String> fr3 = new ArrayList<String>();
	public static ArrayList<String> it3 = new ArrayList<String>();
	public static ArrayList<String> sp3 = new ArrayList<String>();

	public static ArrayList<String> myList = new ArrayList<String>();

	
	public static String input;
	
static int count =0;
	static int count2=0;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	/*	Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter file name (1): ");
		String fname = reader.next();
	
		*/
		
		ArrayList<String> list = new ArrayList<String>();	

	for (int i=1; i<21;i++)	
		readFileWords("warticle-"+i+".txt");

 Set<String> unique = new HashSet<String>(linesw);
 for (String key : unique) {
	 if(Collections.frequency(linesw, key)==4){ // take the maximum number of occurrences (words occurring in each element)
  //   System.out.println(key + ": " + Collections.frequency(linesw, key));
     
     if(key.length()==2)    	 
     letter2.add(key);
     
     if(key.length()==3)
    letter3.add(key);
	 }
 }
//  System.out.println(letter2);
  //System.out.println(letter3);
  int [][]ger=new int [4][17];
  int [][]fr= new int [4][17];
 for (int l=0;l<4;l++ ){
	 for(int s=0;s<17;s++){
		 ger[l][s]=0;
	 }
	 }


 for (int i=1;i<5;i++)
	 readLanguage("warticle-"+i+".txt", "ger");
// System.out.println(lines);
 
	  for (int l=0;l<lines.size();l++){ // arraylist of german words
		  for(int k=0; k<letter3.size();k++)
		  {
	  if(letter3.get(k).toString().contentEquals(lines.get(l).toString())){
			if(!ger3.contains(lines.get(l).toString()))
		  ger3.add(lines.get(l).toString());
		  }
		  }
		  
		  for(int k=0;k<letter2.size();k++)
		  {
			  if(letter2.get(k).toString().equals((lines.get(l).toString()))){
			   if(!ger3.contains(lines.get(l).toString()))
				 ger3.add(lines.get(l).toString()); 
		  }
	      }	
		  
	  }
 
	  
 for (int i=5;i<9;i++)
	 readLanguage("warticle-"+i+".txt", "en");
 
 for (int l=0;l<lines2.size();l++){ // arraylist of english words
	  for(int k=0; k<letter3.size();k++)
	  {	  
 if(letter3.get(k).toString().contentEquals(lines2.get(l).toString())){
		if(!en3.contains(lines2.get(l).toString()))
	 en3.add(lines2.get(l).toString()); 
	  }
 }
	  for(int k=0;k<letter2.size();k++)
	  {
		  if(letter2.get(k).toString().equals((lines2.get(l).toString()))){
		   if(!en3.contains(lines2.get(l).toString()))
			 en3.add(lines2.get(l).toString()); 
	  }
      }
 }
 
 
 for (int i=9;i<13;i++) 
	 readLanguage("warticle-"+i+".txt", "fr");
 
 for (int l=0;l<lines3.size();l++){ // arraylist of french words
	  for(int k=0; k<letter3.size();k++)
	  {
if(letter3.get(k).toString().equals((lines3.get(l).toString()))){
	if(!fr3.contains(lines3.get(l).toString()))
	 fr3.add(lines3.get(l).toString());
}
	  }
	  
	  for(int k=0;k<letter2.size();k++)
	  {
		  if(letter2.get(k).toString().equals((lines3.get(l).toString()))){
		   if(!fr3.contains(lines3.get(l).toString()))
			 fr3.add(lines3.get(l).toString()); 
	  }
      }	
	  
}
 
 
 for (int i=13;i<17;i++){
	 readLanguage("warticle-"+i+".txt", "it");
 }
	 for (int l=0;l<lines4.size();l++){ // arraylist of italian words
		  for(int k=0; k<letter3.size();k++)
		  {
	if(letter3.get(k).toString().equals((lines4.get(l).toString()))){
		if(!it3.contains(lines4.get(l).toString()))
		it3.add(lines4.get(l).toString());
	}
		  }
		  for(int k=0;k<letter2.size();k++)
		  {
			  if(letter2.get(k).toString().equals((lines4.get(l).toString()))){
			   if(!it3.contains(lines4.get(l).toString()))
				 it3.add(lines4.get(l).toString()); 
		  }
	 }	
		  
		  
	}
 
 
 
 for (int i=17;i<21;i++){
	 readLanguage("warticle-"+i+".txt", "sp");
 }
 for (int l=0;l<lines5.size();l++){ // arraylist of spanish words
	  for(int k=0; k<letter3.size();k++)
	  {
    if(letter3.get(k).toString().equals((lines5.get(l).toString()))){
    if(!sp3.contains(lines5.get(l).toString()))
	 sp3.add(lines5.get(l).toString());
}
}
	  for(int k=0;k<letter2.size();k++)
	  {
		  if(letter2.get(k).toString().equals((lines5.get(l).toString()))){
		   if(!sp3.contains(lines5.get(l).toString()))
			 sp3.add(lines5.get(l).toString()); 
	  }
 }
	
	  	  
 }
 
 
 
 input="The United Kingdom is a constitutional monarchy with a parliamentary system of governance. Its capital city is London, an important global city and financial centre with an urban population of 10,310,000, the fourth-largest in Europe and second-largest in the European Union.";
 //input2="";

/*
{
	for (int s=0; s<sp3.size(); s++){
		if(words[i].contains(sp3.get(s).toString()))
		sp=1;
	}
	
	for(int k=0; k<it3.size(); k++){
		if(words[i].contentEquals((it3.get(k).toString())))
			it=1;
}
	for (int h=0; h<ger3.size();h++){
		if(words[i].contentEquals((ger3.get(h).toString())))
			gr=1;	
		
	for(en=0; en<en3.size();en++)	{
		if(words[i].contentEquals((en3.get(en).toString())))
			en=1;	
	}
	
	for(fr2=0; fr2<fr3.size();fr2++)	{
		if(words[i].contentEquals((fr3.get(en).toString())))
			fr2=1;	
	}
		
	} 
}

*/




 System.out.println("*****");
/* Set<String> unique2 = new HashSet<String>(sp3);
 for (String key : unique2) {
	if(input.contains(key))
		sp=1;
 }
Set<String>	 unique3 = new HashSet<String>(it3);
for(String key3 : unique3){
   if(input.contains(key3))
     it =1;
}
*/
 
detectLanguage(input);

}
	

public static void readFileWords(String fname){
	 String fileName = fname;
     
     // This will reference one line at a time
     String line = null;
    
     try {
         // FileReader reads text files in the default encoding.
         FileReader fileReader = 
             new FileReader(fileName);
        
         
         // Always wrap FileReader in BufferedReader.
         BufferedReader bufferedReader = 
             new BufferedReader(fileReader);
        
         String firstLine = bufferedReader.readLine();  // bufferedReader were skipping first line
     
        	 if(!isInteger(firstLine))
        	 linesw.add(firstLine);
         while((line = bufferedReader.readLine()) != null) {
        //     System.out.println(line);
        	 if(!isInteger(line))
             linesw.add(line);	
        
         }
         
         // Always close files.
         bufferedReader.close();       
         
     }
     catch(FileNotFoundException ex) {
         System.out.println(
             "Unable to open file '" + 
             fileName + "'");                
     }
     catch(IOException ex) {
         System.out.println(
             "Error reading file '" 
             + fileName + "'");                  
         // Or we could just do this: 
         // ex.printStackTrace();
     }
	
}

public static void readLanguage(String fname,String lang){
 String fileName = fname;
     
     // This will reference one line at a time
     String line = null;
    
     try {
         // FileReader reads text files in the default encoding.
         FileReader fileReader = 
             new FileReader(fileName);
        
         
         // Always wrap FileReader in BufferedReader.
         BufferedReader bufferedReader = 
             new BufferedReader(fileReader);
        
         String firstLine = bufferedReader.readLine();  // bufferedReader were skipping first line
         if(lang=="ger"){
        	 if(!isInteger(firstLine))
        	 lines.add(firstLine);
         while((line = bufferedReader.readLine()) != null) {
        //     System.out.println(line);
        	 if(!isInteger(line))
             lines.add(line);	
         }     
         }
         
         if (lang=="en"){
        	 if(!isInteger(firstLine))
            	 lines2.add(firstLine);
             while((line = bufferedReader.readLine()) != null) {
            //     System.out.println(line);
            	 if(!isInteger(line))
                 lines2.add(line);	
             }     
        	 
         }
        	 if(lang=="fr"){
        		 if(!isInteger(firstLine))
                	 lines3.add(firstLine);
                 while((line = bufferedReader.readLine()) != null) {
                //     System.out.println(line);
                	 if(!isInteger(line))
                     lines3.add(line);	
                 }      
        	 }
        	 
        		 
        		 if(lang=="it"){
        			 if(!isInteger(firstLine))
                    	 lines4.add(firstLine);
                     while((line = bufferedReader.readLine()) != null) {
                    //     System.out.println(line);
                    	 if(!isInteger(line))
                         lines4.add(line);	
                     }  
        		 }
        		 
        			 if(lang=="sp"){
        				 if(!isInteger(firstLine))
                        	 lines5.add(firstLine);
                         while((line = bufferedReader.readLine()) != null) {
                        //     System.out.println(line);
                        	 if(!isInteger(line))
                             lines5.add(line);	
                         }  	 
        				 
        			 }
         
         // Always close files.
         bufferedReader.close();       
         
     }
     catch(FileNotFoundException ex) {
         System.out.println(
             "Unable to open file '" + 
             fileName + "'");                
     }
     catch(IOException ex) {
         System.out.println(
             "Error reading file '" 
             + fileName + "'");                  
         // Or we could just do this: 
         // ex.printStackTrace();
     }
	
}


public static void detectLanguage(String input){
		 
	 input.replaceAll("'", "");
	 input.replaceAll(",", "");
	 input.replaceAll(";", "");
	 input.replaceAll(".", "");
	 
	 String words[] = input.split(" ");

	 int sp=0;
	int it=0;
	int gr=0;
	int en=0;
	int fr2=0;

	for (int i=0; i<words.length;i++){
	//	System.out.println(words[i]);
		
	if(words[i]=="for" || words[i]=="is" || words[i]=="are" || words[i]=="it" || words[i]=="has" || words[i]=="the" || words[i]=="of"){
		en=1;
		System.out.println("English");
	}
	else if (words[i]=="che" || words[i]=="ed" || words[i]=="nel" ||  words[i]=="per" || words[i]=="pi" || words[i]=="si" ){
	 it=1;
	}
	else if (words[i]=="das" || words[i]=="die" || words[i]=="der" || words[i]=="im" || words[i]=="ist") {
	gr=1;
	}
	else if (words[i]=="el" || words[i]=="fue" || words[i]=="las" || words[i]=="los" || words[i]=="ms"||  words[i]=="pas" || words[i]=="por" )
	{
		sp=1;
	}
	else if (words[i]=="au" || words[i]=="du" || words[i]=="et" || words[i]=="les" || words[i]=="dans" || words[i]=="où")
	{
		fr2=1;
	}
	
	}
	if(sp==1)
		System.out.println("Spanish");

		if(it==1)
			System.out.println("Italian");

		if(fr2==1)
			System.out.println("French");

		if(en==1)
			System.out.println("English");

		if(gr==1)
			System.out.println("German");	
		
}
	

public static boolean isInteger(String str) {
    try {
        Integer.parseInt(str);
        return true;
    } catch (NumberFormatException nfe) {}
    return false;
}


}


