import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;


class Counter2 {
public String filename;

private static LinkedList<String> keywordsList;

public static String name;
public static String name2;
public static int flag=0;
private static TreeMap<String, Integer> freqMap;
public static ArrayList<String> words= new ArrayList<String>();

static int[] counts;
static int[] sorted_counts;
public static int count=0;
public static int count2=0;
static volatile boolean finished = false;

Counter2(String filename,int flag){
this.filename=filename;
freqMap=new TreeMap<String,Integer>();
keywordsList=new LinkedList<String>();
this.flag=flag;
}

public static void main(String[] args){
		
	Scanner reader = new Scanner(System.in);  // Reading from System.in
	System.out.println("Enter file name (1): ");
	String fname = reader.next();
	String original1="article-"+fname;
//	String original1=fname;
	
	//name = "freq"+fname+".txt";
	name = "w"+original1+".txt";
	
Counter2 counter= new Counter2(original1+".txt",flag);
	counter.processCounting();		
	
/*	String fname;
	for(k=1;k<6;k++){
	fname="article-"+k ;
	name = "freq"+fname+".txt";
Counter counter= new Counter(fname+".txt");
counter.processCounting();
	}
	
	for(k=1;k<6;k++){
	 fname="article-"+k+"-"+1 ;
	name = "freq"+fname+".txt";
Counter counter= new Counter(fname+".txt");
counter.processCounting();
	}
	for(k=1;k<6;k++){
	fname="article-"+k+"-"+2 ;
	name = "freq"+fname+".txt";
Counter counter= new Counter(fname+".txt");
counter.processCounting();
	}
	for(k=1;k<6;k++){
	fname="article-"+k+"-"+"a" ;
	name = "freq"+fname+".txt";
Counter counter= new Counter(fname+".txt");
counter.processCounting();
	}
	for(k=1;k<6;k++){
		fname="article-"+k+"-"+"b" ;
		name = "freq"+fname+".txt";
	Counter counter= new Counter(fname+".txt");
	counter.processCounting();
		}
	*/
}
public void readWords(){
Pattern pattern=Pattern.compile("\\W+"); 
try {

FileReader fr=new FileReader(filename);
BufferedReader br = new BufferedReader(fr);
String strLine;
while((strLine=br.readLine())!=null){
//split a line by spaces so we get words
String[] words=strLine.split("[ ]+");
for(String word:words){
//remove all symbols except underscore
Matcher mat=pattern.matcher(word);
word=mat.replaceAll("");
//add words to the list

keywordsList.add(removeStopWords(word.toLowerCase()));
}
}


br.close();
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}


public void countWords(){
int count=1;
String word="";
for(int i=0;i<keywordsList.size();i++){
word=keywordsList.get(i);

for(int j=i+1;j<keywordsList.size();j++){
if(word.equals(keywordsList.get(j))){
count++; //increase the number of duplicate words 
}
}
//add the word and its frequency to the TreeMap
addToMap(word,count);
//reset the count variable
count=1;
}

}

public void addToMap(String word, int count){
//place keyword and its frequency in TreeMap
if(!freqMap.containsKey(word) && word.length()>=1){ 
freqMap.put(word, count);

}

} 


public static void writeToFile(String name)
{
	
	try {


		File file = new File(name);
		
      
		// if file doesn't exists, then create it
		if (!file.exists()) {
			file.createNewFile();
		}

		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter((new OutputStreamWriter(
			    new FileOutputStream(file), "UTF-8")));
		
		Set<String> keys=freqMap.keySet();
		int numWord=keys.size();
		Iterator<String> iterator=keys.iterator();
		while(iterator.hasNext()){
		String word=iterator.next();
		int count=freqMap.get(word); 
//	bw.write(word+ "     " + count+"\n" );
		bw.write(word+"\n");
		}
		bw.close();
	//	System.out.println("Done");

	} catch (IOException e) {
		e.printStackTrace();
	}
	
}




public void processCounting(){
Thread backprocess=new Thread(){
public void run(){ 
	
readWords();
countWords();

writeToFile(name);

}

};
backprocess.start();
}



private static String removeStopWords(String x) {
    String tmp;
    tmp = x.toLowerCase();
    if(tmp.equals("and"))
    tmp = tmp.replace("and", "");
    if(tmp.equals("of"))
    tmp = tmp.replace("of", "");
    if(tmp.equals("with"))
    tmp = tmp.replace("with", "");
    if(tmp.equals("a"))
    tmp = tmp.replace("a", "");
    if(tmp.equals("which"))
    tmp = tmp.replace("which", "");
    if(tmp.equals("what"))
    tmp = tmp.replace("what", "");
    if(tmp.equals("with"))
    tmp = tmp.replace("with", "");
    if(tmp.equals("here"))
    tmp = tmp.replace("here", "");
    if(tmp.equals("there"))
    tmp = tmp.replace("there", "");
    if(tmp.equals("or"))
    tmp = tmp.replace("or", "");
    if(tmp.equals("the"))
    tmp = tmp.replace("the", "");
    if(tmp.equals("on"))
    tmp = tmp.replace("on", "");
    if(tmp.equals("on"))
    tmp = tmp.replace("in", "");
    if(tmp.equals("an"))
        tmp = tmp.replace("an", "");
    if(tmp.equals("at"))
        tmp = tmp.replace("at", ""); 
    
    if(tmp.equals("to"))
        tmp = tmp.replace("to", ""); 
    
    if(tmp.equals("who"))
        tmp = tmp.replace("who", ""); 
    
    if(tmp.equals("but"))
        tmp = tmp.replace("but", ""); 
    
    if(tmp.equals("was"))
        tmp = tmp.replace("was", ""); 
    
    if(tmp.equals("were"))
        tmp = tmp.replace("were", ""); 
    
    if(tmp.equals("by"))
        tmp = tmp.replace("by", ""); 
    
    if(tmp.equals("are"))
        tmp = tmp.replace("are", ""); 
    if(tmp.equals("is"))
        tmp = tmp.replace("is", ""); 
    if(tmp.equals("them"))
        tmp = tmp.replace("them", ""); 
    if(tmp.equals("than"))
        tmp = tmp.replace("than", ""); 
    
    if(tmp.equals("as"))
        tmp = tmp.replace("as", ""); 
    
    if(tmp.equals("other"))
        tmp = tmp.replace("other", ""); 
    
    if(tmp.equals("no"))
        tmp = tmp.replace("no", ""); 
    if(tmp.equals("all"))
        tmp = tmp.replace("all", ""); 
    
    if(tmp.equals("that"))
        tmp = tmp.replace("that", ""); 
    if(tmp.equals("where"))
        tmp = tmp.replace("where", ""); 
    if(tmp.equals("their"))
        tmp = tmp.replace("their", ""); 
    
    return tmp;
}


}








