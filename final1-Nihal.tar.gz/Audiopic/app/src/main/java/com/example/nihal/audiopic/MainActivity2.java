package com.example.nihal.audiopic;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.speech.RecognizerIntent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import java.io.IOException;
import java.util.ArrayList;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity2 extends ActionBarActivity {
    static MediaPlayer mPlayer;
    Button buttonPlay;
    Button buttonRec;
    Button buttonNext;
    ImageView image;
    ArrayList<String> matches_text;
    String x;
    TextView Speech;
    TextView Result;
  //  ImageView image1;
  //  ImageView image2;
    private static final int REQUEST_CODE = 1234;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);

        buttonPlay = (Button) findViewById(R.id.play);
        buttonPlay.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {

                Uri myUri1 = Uri.parse("android.resource://com.example.nihal.audiopic/" + R.raw.bear);
                mPlayer = new MediaPlayer();
                mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                try {
                    mPlayer.setDataSource(getApplicationContext(), myUri1);
                } catch (IllegalArgumentException e) {
                    Toast.makeText(getApplicationContext(), "You might not set the URI correctly!", Toast.LENGTH_LONG).show();
                } catch (SecurityException e) {
                    Toast.makeText(getApplicationContext(), "You might not set the URI correctly!", Toast.LENGTH_LONG).show();
                } catch (IllegalStateException e) {
                    Toast.makeText(getApplicationContext(), "You might not set the URI correctly!", Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    mPlayer.prepare();
                } catch (IllegalStateException e) {
                    Toast.makeText(getApplicationContext(), "You might not set the URI correctly!", Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    Toast.makeText(getApplicationContext(), "You might not set the URI correctly!", Toast.LENGTH_LONG).show();
                }
                mPlayer.start();
            }

        });

        buttonRec = (Button) findViewById(R.id.recognize);

        buttonRec.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isConnected()) {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,
                            "en-US");
                    startActivityForResult(intent, REQUEST_CODE);
                } else {
                    Toast.makeText(getApplicationContext(), "Plese Connect to Internet", Toast.LENGTH_LONG).show();
                }
            }

        });
        addListenerOnButton();
    }

    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo net = cm.getActiveNetworkInfo();
        if (net != null && net.isAvailable() && net.isConnected()) {
            return true;
        } else {
            return false;
        }
    }
//DIGER EKRANLARA GENELLESTIR: xml ve class dosyalarini degistir mainler icin, copy paste ile degistir xmlleri, cunku structure
    //degisti.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {



        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {


            matches_text = data
                    .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

            x = matches_text.get(0);

            Speech = (TextView) findViewById(R.id.speech);
            Speech.setText("You've said " + "\"" + x + "\"");

            Result = (TextView) findViewById(R.id.result);
            if (x.equals("bear")) {
                  Result.setText("CORRECT. Well done!");
            /*    image2 = (ImageView) findViewById(R.id.imageView3);
                image2.setVisibility(View.VISIBLE);
                image2.setImageResource(R.mipmap.happy);
                */

            } else {
                /*
                image1=  (ImageView)findViewById(R.id.imageView4) ;
                image1.setVisibility(View.VISIBLE);
                image1.setImageResource(R.mipmap.sad);
                */
                Result.setText("WRONG! Try again...");
            }
        }

        image = (ImageView) findViewById(R.id.imageView1);
        image.setImageResource(R.mipmap.bear);

    }

    protected void onDestroy() {
        super.onDestroy();
        // TODO Auto-generated method stub
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
    }

    public void addListenerOnButton() {

        final Context context = this;

        buttonNext = (Button) findViewById(R.id.button2);

        buttonNext.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, MainActivity3.class);
                startActivity(intent);

            }

        });

    }

}