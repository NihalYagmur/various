package com.example.nihal.audiopic;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.speech.RecognizerIntent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class Activity5 extends Activity4 {

    static MediaPlayer mPlayer;

    Button buttonRec;
    Button buttonNext;
    ImageView image;
    ArrayList<String> matches_text;
    String x;
  int cr;
    TextView Result;
    ImageView image1;
    ImageView image2;

    private static final int REQUEST_CODE = 1234;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity5);
        Intent intent = getIntent();

        cr = intent.getIntExtra("result", c);
        buttonRec = (Button) findViewById(R.id.recognize);

        buttonRec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isConnected()) {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,
                            "en-US");
                    startActivityForResult(intent, REQUEST_CODE);
                } else {
                    Toast.makeText(getApplicationContext(), "Plese Connect to Internet", Toast.LENGTH_LONG).show();
                }
            }

        });
        addListenerOnButton();
    }

    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo net = cm.getActiveNetworkInfo();
        if (net != null && net.isAvailable() && net.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        matches_text = data
                .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

        x = matches_text.get(0);

        Speech = (TextView) findViewById(R.id.speech);
        Speech.setText("You've said " + "\"" +x+ "\"" );

        Result = (TextView) findViewById(R.id.result);
        if(x.equals("bird")) {
            cr++;
            image2=  (ImageView)findViewById(R.id.imageView2) ;
            image2.setVisibility(View.VISIBLE);
            image2.setImageResource(R.mipmap.happy);
        }
        else {
            wrong++;
            image1=  (ImageView)findViewById(R.id.imageView) ;
            image1.setVisibility(View.VISIBLE);
            image1.setImageResource(R.mipmap.sad);
        }

        image = (ImageView) findViewById(R.id.imageView1);
        image.setImageResource(R.mipmap.bird);

        buttonRec.setEnabled(false);
    }

    protected void onDestroy() {
        super.onDestroy();
        // TODO Auto-generated method stub
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
    }

    public void addListenerOnButton() {

        final Context context = this;

        buttonNext = (Button) findViewById(R.id.button3);

        buttonNext.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(getBaseContext(), Activity6.class);

                intent.putExtra("result", cr);
                startActivity(intent);

            }

        });

    }
}
