import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class Last {
	public static ArrayList<String> lines = new ArrayList<String>();
	public static ArrayList<String> lines2 = new ArrayList<String>();
	
	public static ArrayList<String> linesw = new ArrayList<String>();
	public static ArrayList<String> lines2w = new ArrayList<String>();
	
	public static ArrayList<String> nums = new ArrayList<String>();
	public static ArrayList<String> nums2 = new ArrayList<String>();
	
	public static ArrayList<String> days = new ArrayList<String>();
	public static ArrayList<String> days2 = new ArrayList<String>();
	
	public static ArrayList<String> linest = new ArrayList<String>();
	public static ArrayList<String> lines2t = new ArrayList<String>();
	
static int count =0;
	static int count2=0;
	static int count3=0;
	public static double score=0;
	public static double score2=0;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter file name (1): ");
		String fname = reader.next();
	
		Scanner reader2 = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter file name (2): ");
		String fname2 = reader.next();
		
		
 
  readFileWords("warticle-"+fname+ ".txt");
int lengthw= linesw.size();
  

 readFileWords("warticle-"+ fname2+".txt");
  int length2w= lines2w.size();
  int j;
  int k;
  System.out.println(linesw);
  
	}
public static void readFile(String fname){
		
	 
        // The name of the file to open.
        String fileName = fname;
    
        // This will reference one line at a time
        String line=null;
      
        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);
           
            
            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);
            // solution for not skipping first line (it was doing that for second file read)
            String firstLine = bufferedReader.readLine();  // bufferedReader were skipping first line
           
            if(count==0){
            	lines.add(firstLine);
            //  line= bufferedReader.readLine();
            while((line = bufferedReader.readLine()) != null) {
           //     System.out.println(line);
            	
                lines.add(line);	
            }   
            }
            if(count==1){
            	lines2.add(firstLine);
            while((line = bufferedReader.readLine()) != null) {
                //     System.out.println(line);
            	lines2.add(line);
            } 
            }
            // Always close files.
            bufferedReader.close();  
           
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
        count++;
}

public static void readFileWords(String fname){
	 String fileName = fname;
     
     // This will reference one line at a time
     String line = null;
    
     try {
         // FileReader reads text files in the default encoding.
         FileReader fileReader = 
             new FileReader(fileName);
        
         
         // Always wrap FileReader in BufferedReader.
         BufferedReader bufferedReader = 
             new BufferedReader(fileReader);
        
         String firstLine = bufferedReader.readLine();  // bufferedReader were skipping first line
         if(count2==0){
        	 linesw.add(firstLine);
         while((line = bufferedReader.readLine()) != null) {
        //     System.out.println(line);
             linesw.add(line);	
         }   
         }
         if(count2==1){
        	 lines2w.add(firstLine);
         while((line = bufferedReader.readLine()) != null) {
             //     System.out.println(line);
         	
         	lines2w.add(line);
         } 
         }
         // Always close files.
         bufferedReader.close();       
         
     }
     catch(FileNotFoundException ex) {
         System.out.println(
             "Unable to open file '" + 
             fileName + "'");                
     }
     catch(IOException ex) {
         System.out.println(
             "Error reading file '" 
             + fileName + "'");                  
         // Or we could just do this: 
         // ex.printStackTrace();
     }
	count2++;
}



}  
